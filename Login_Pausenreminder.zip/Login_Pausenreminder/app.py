from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def root():
   return render_template('root.html', name='root')

@app.route('/meeting')
def meeting():
   return render_template('meeting.html', name='meeting')

@app.route('/office')
def office():
   return render_template('office.html', name='office')