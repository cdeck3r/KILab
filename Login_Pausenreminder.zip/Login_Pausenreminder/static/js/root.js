function pushnotif(){
    Push.create("Pausenreminder", {
        body: "Legen Sie bitte eine Pause ein, falls Sie in den letzten 90 Minuten noch keine gemacht haben."
    });
}